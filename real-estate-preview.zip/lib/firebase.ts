import { initializeApp, getApps, getApp } from "firebase/app"
import { getFirestore } from "firebase/firestore"

const firebaseConfig = {
  apiKey: "AIzaSyDdw3e-u0OfhwMMBp5XctG94vDZTPMWDhc",
  authDomain: "learning-a2c54.firebaseapp.com",
  projectId: "learning-a2c54",
  storageBucket: "learning-a2c54.appspot.com",
  messagingSenderId: "451781962823",
  appId: "1:451781962823:web:8a928fd7b2a2ffcebad562",
  measurementId: "G-WJJFDNK42Z",
}

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp()
const db = getFirestore(app)

export { db }
